package qa.java.classes;

public class TestC 
{
	
	public static void main(String[] args) 
	{
		
		System.out.println("Hello World");
			
		/*
		 * Note:--> In java execution starts from main method
		 * 			
		 */
		
	}

}
