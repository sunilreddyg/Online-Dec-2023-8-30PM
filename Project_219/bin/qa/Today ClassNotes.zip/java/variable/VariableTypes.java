package qa.java.variable;

public class VariableTypes {

}
