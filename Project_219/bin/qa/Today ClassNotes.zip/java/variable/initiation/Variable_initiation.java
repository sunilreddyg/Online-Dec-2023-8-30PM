package qa.java.variable.initiation;

public class Variable_initiation {

	public static void main(String[] args) 
	{
		//First method
		int a=100;  //Variable declaration and initialize data
		System.out.println("before assign value:-->"+a);
		a=200;
		System.out.println("after override value:--> "+a);
		
		
		
		
		int b;    //Declaration of variable
		b=200;    //initialize data to variable
		System.out.println("after data assign:--> "+b);
		b=300;
		System.out.println("After override value:--> "+b);
		
		
		
	}

}
