package qa.java.methods.Parameters.CallByReference;

public class Product2 
{
	String name="Iphone";
	public void printprice(double price)
	{
		System.out.println(price);
	}

}
