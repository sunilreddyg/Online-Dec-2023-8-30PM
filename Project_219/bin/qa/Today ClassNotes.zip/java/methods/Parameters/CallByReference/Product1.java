package qa.java.methods.Parameters.CallByReference;

public class Product1 
{
	String name="Samsung";
	
	void printprice(double price)
	{
		System.out.println(price);
	}

}
