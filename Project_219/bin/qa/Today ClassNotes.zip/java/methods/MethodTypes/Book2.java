package qa.java.methods.MethodTypes;

public class Book2 
{
	String name="Selenium2";

	double getprice()
	{
		return 1000;
	}

	void printAuthor()
	{	
		System.out.println("Sunil");
	}

}
