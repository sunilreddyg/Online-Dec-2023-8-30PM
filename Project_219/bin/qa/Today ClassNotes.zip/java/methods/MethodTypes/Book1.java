package qa.java.methods.MethodTypes;

public class Book1 
{
	String name="Selenium1";

	double getprice()
	{
		return 500;
	}

	void printAuthor()
	{
		System.out.println("Kiran");
	}

}
