package qa.java.classes;

public class TestB 
{
	
	//PUBLIC modifier class
	//This class information we can use outside the
	//package with in project

	

}
