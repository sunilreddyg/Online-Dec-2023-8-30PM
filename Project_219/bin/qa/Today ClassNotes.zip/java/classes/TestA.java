package qa.java.classes;

class TestA 
{
	//NO modifier class
	//WE can use class information with in package only
	
}
